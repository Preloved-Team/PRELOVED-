import React from 'react'
import ActivityStyle from './Activity.css';

const Activity = () => {
  return (
    <div>
      <h1>NOTIFICATINS</h1>
    </div>
  )
}

export default Activity
