import React from 'react'

const Register = () => {
  return (
    <div>
      <h1>register page</h1>
    </div>
  )
}

export default Register
