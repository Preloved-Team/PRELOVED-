import React from 'react'

const AdminDashboard = () => {
  return (
    <div>
      <h1>admin page</h1>
    </div>
  )
}

export default AdminDashboard
