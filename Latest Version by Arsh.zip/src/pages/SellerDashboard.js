import React from 'react'

const SellerDashboard = () => {
  return (
    <div>
      <h1>seller page</h1>
    </div>
  )
}

export default SellerDashboard
