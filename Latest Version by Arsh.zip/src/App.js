import { BrowserRouter as Router, Routes, Route, useLocation, useParams } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminDashboard from './pages/AdminDashboard';
import BuyerDashboard from './pages/BuyerDashboard';
import SellerDashboard from './pages/SellerDashboard';
import ShopCategory from './pages/ShopCategory';
import Navbar from './components/navbar/navbar';
import Product from './pages/Product';
import Cart from './pages/Cart';

// Banners
import PreLoved_banner from './components/Assets/preloved banner.jpeg';
import Clothing_banner from './components/Assets/Clothing_Accessories banner.jpeg';
import Electrnic_Banner from './components/Assets/Electronics_Gadgets.jpg';
import Home_banner from './components/Assets/Home_Living.jpg';
import Kids_banner from './components/Assets/Kids_Baby_Items.webp';
import Vechile_banner from './components/Assets/Vehicles_Automotive.jpeg';

function AppWrapper() {
  const location = useLocation();
  const hideNavbar = location.pathname === '/' || location.pathname === '/login';

  // Optional: dynamic banner assignment for `/category/:categoryName`
  const bannerMap = {
    'clothing_accessories': Clothing_banner,
    'electronics_gadgets': Electrnic_Banner,
    'home_living': Home_banner,
    'kids_baby_items': Kids_banner,
    'vehicles_automotive': Vechile_banner,
    'men': Clothing_banner,
    'women': Clothing_banner,
    'kids': Kids_banner,
    'electronics': Electrnic_Banner,
    'appliances': Home_banner
  };

  return (
    <>
      {!hideNavbar && <Navbar />}
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/adminDashboard" element={<AdminDashboard />} />
        <Route path="/buyerDashboard/*" element={<BuyerDashboard />} />
        <Route path="/sellerDashboard" element={<SellerDashboard />} />

        {/* Static category routes (optional if using dynamic route below) */}
        <Route path="/clothing_accessories" element={<ShopCategory banner={Clothing_banner} category="Clothing_Accessories" />} />
        <Route path="/electronics_gadgets" element={<ShopCategory banner={Electrnic_Banner} category="Electronics_Gadgets" />} />
        <Route path="/home_living" element={<ShopCategory banner={Home_banner} category="Home_Living" />} />
        <Route path="/kids_baby_items" element={<ShopCategory banner={Kids_banner} category="Kids_Baby_Items" />} />
        <Route path="/vehicles_automotive" element={<ShopCategory banner={Vechile_banner} category="Vehicles_Automotive" />} />

        {/* Dynamic category route for Men, Women, Kids, Electronics, Appliances, etc. */}
        <Route
          path="/category/:categoryName"
          element={
            <CategoryRouteWrapper bannerMap={bannerMap} />
          }
        />

        <Route path="/product/:productID" element={<Product />} />
        <Route path="/cart" element={<Cart />} />

        {/* Optional: 404 fallback */}
        <Route path="*" element={<h2 style={{ textAlign: 'center', marginTop: '50px' }}>404 - Page Not Found</h2>} />
      </Routes>
    </>
  );
}

// Wrapper to extract category param and pass it + correct banner to ShopCategory
function CategoryRouteWrapper({ bannerMap }) {
  const { categoryName } = useParams();
  const normalized = categoryName.toLowerCase();
  const banner = bannerMap[normalized] || PreLoved_banner;

  return <ShopCategory category={categoryName} banner={banner} />;
}

function App() {
  return (
    <Router>
      <AppWrapper />
    </Router>
  );
}

export default App;
